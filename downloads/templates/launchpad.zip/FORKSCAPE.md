# Launchpad — project knowledge

An animated landing page (static HTML/CSS/JS — no npm, no bundler). Run app
serves index.html directly.

## Where things live (edit here, not everywhere)
- **content.json** — EVERYTHING a marketer would touch: brand, accent +
  accent2 gradient, eyebrow/headline/subline, CTAs, logo row, features,
  stats, pricing tiers, FAQ, footer. "Rebrand this for <product>" =
  rewrite content.json. Keep it valid JSON.
- **styles.css** — design tokens at :root; scroll-reveal + keyframes named
  and grouped. Restyle by tokens first.
- **scene.js** — the three.js hero (particle galaxy + wireframe torus knot,
  mouse parallax). three.js loads from the CDN; a canvas-2D starfield
  fallback runs when the CDN is unreachable — keep BOTH paths working.
- **main.js** — renders content.json into the DOM and wires scroll reveals,
  count-up stats, and pricing-card tilt.

## Rules
- Keep it buildless: no npm installs, no frameworks.
- The last two headline words get the gradient shimmer automatically.
- Keep new motion inside the prefers-reduced-motion guards (the hero canvas
  is skipped entirely there).
- Verify with the live-test agent (app_interact) after changes.
