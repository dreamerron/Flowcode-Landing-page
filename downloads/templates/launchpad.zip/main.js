// Launchpad — content.json drives every word and color on the page.
const $ = (s) => document.querySelector(s);

fetch('content.json').then((r) => r.json()).then((c) => {
  document.title = c.brand;
  document.documentElement.style.setProperty('--accent', c.accent);
  document.documentElement.style.setProperty('--accent2', c.accent2 ?? c.accent);
  $('#nav-name').textContent = c.brand;
  $('#eyebrow').textContent = c.eyebrow;

  // Headline: word-by-word staggered entrance; the last two words get the
  // shimmering gradient treatment.
  const words = c.headline.split(' ');
  $('#headline').innerHTML = words
    .map((w, i) => '<span class="w' + (i >= words.length - 2 ? ' grad' : '') + '" style="--d:' + (0.15 + i * 0.07) + 's">' + w + '</span>')
    .join(' ');

  $('#subline').textContent = c.subline;
  $('#cta-main').textContent = c.ctaMain;
  $('#cta-alt').textContent = c.ctaAlt;
  $('#logos').innerHTML = c.logos.map((l) => '<span>' + l + '</span>').join('');

  $('#feature-grid').innerHTML = c.features
    .map((f, i) => '<div class="card" style="--d:' + i * 0.08 + 's"><span class="fic">' + f.icon + '</span><h3>' + f.title + '</h3><p>' + f.text + '</p></div>')
    .join('');

  $('#stats').innerHTML = c.stats
    .map((s, i) => '<div class="stat" style="--d:' + i * 0.1 + 's"><b data-target="' + s.value + '" data-suffix="' + s.suffix + '">0' + s.suffix + '</b><span>' + s.label + '</span></div>')
    .join('');

  $('#tiers').innerHTML = c.tiers
    .map((t, i) =>
      '<div class="tier' + (t.popular ? ' popular' : '') + '" style="--d:' + i * 0.1 + 's">' +
      (t.popular ? '<span class="pop">POPULAR</span>' : '') +
      '<h3>' + t.name + '</h3><p class="price">' + t.price + '</p><p class="per">' + t.period + '</p>' +
      '<ul>' + t.items.map((x) => '<li>' + x + '</li>').join('') + '</ul>' +
      '<a class="btn ' + (t.popular ? 'primary' : 'ghost') + '" href="#">Choose ' + t.name + '</a></div>')
    .join('');

  $('#faq-list').innerHTML = c.faq
    .map((f, i) => '<details style="--d:' + i * 0.08 + 's"><summary>' + f.q + '</summary><p>' + f.a + '</p></details>')
    .join('');

  $('#footer-line').textContent = c.footerLine;
  $('#cta-footer').textContent = c.ctaMain;
  $('#footer-fine').textContent = c.footerFine;

  wire();
});

function wire() {
  // Scroll reveal — everything with the transition pair fades up on entry.
  const io = new IntersectionObserver((es) => {
    for (const e of es) if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }, { threshold: 0.15 });
  document.querySelectorAll('.reveal, .card, .stat, .tier, details').forEach((el) => io.observe(el));

  // Count-up stats when the band scrolls in.
  const cio = new IntersectionObserver((es) => {
    for (const e of es) {
      if (!e.isIntersecting) continue;
      cio.unobserve(e.target);
      const b = e.target, target = +b.dataset.target, suffix = b.dataset.suffix;
      const t0 = performance.now(), dur = 1400;
      const step = (t) => {
        const p = Math.min(1, (t - t0) / dur);
        b.textContent = Math.round(target * (1 - Math.pow(1 - p, 3))).toLocaleString() + suffix;
        if (p < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    }
  }, { threshold: 0.5 });
  document.querySelectorAll('.stat b').forEach((b) => cio.observe(b));

  // Pointer tilt on pricing cards.
  if (!matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.querySelectorAll('.tier').forEach((card) => {
      card.addEventListener('pointermove', (e) => {
        const r = card.getBoundingClientRect();
        const rx = ((e.clientY - r.top) / r.height - 0.5) * -8;
        const ry = ((e.clientX - r.left) / r.width - 0.5) * 10;
        card.style.transform = 'rotateX(' + rx + 'deg) rotateY(' + ry + 'deg) translateY(-4px)';
      });
      card.addEventListener('pointerleave', () => { card.style.transform = ''; });
    });
  }
}
