// The hero: a three.js particle nebula with mouse parallax. three.js loads
// from the CDN; when that fails (offline, blocked), a lightweight canvas-2D
// starfield takes over so the page never ships a dead hero.
(function () {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const canvas = document.getElementById('scene');
  let mx = 0, my = 0;
  addEventListener('pointermove', (e) => {
    mx = (e.clientX / innerWidth - 0.5) * 2;
    my = (e.clientY / innerHeight - 0.5) * 2;
  });
  const accent = () => getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#7c6cf6';
  const accent2 = () => getComputedStyle(document.documentElement).getPropertyValue('--accent2').trim() || '#2dd4bf';

  // ── three.js path ─────────────────────────────────────────────────────────
  function startThree(THREE) {
    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.1, 100);
    camera.position.z = 8;

    const N = 2600, pos = new Float32Array(N * 3), col = new Float32Array(N * 3);
    const c1 = new THREE.Color(accent()), c2 = new THREE.Color(accent2());
    for (let i = 0; i < N; i++) {
      // A flattened galaxy disc with a soft vertical spread.
      const r = 2.2 + Math.pow(Math.random(), 0.6) * 9;
      const a = Math.random() * Math.PI * 2;
      pos[i * 3] = Math.cos(a) * r;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 2.4;
      pos[i * 3 + 2] = Math.sin(a) * r - 4;
      const c = c1.clone().lerp(c2, Math.random());
      col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    const pts = new THREE.Points(geo, new THREE.PointsMaterial({ size: 0.05, vertexColors: true, transparent: true, opacity: 0.85, depthWrite: false, blending: THREE.AdditiveBlending }));
    scene.add(pts);
    const knot = new THREE.Mesh(
      new THREE.TorusKnotGeometry(1.5, 0.42, 140, 20),
      new THREE.MeshBasicMaterial({ color: c1, wireframe: true, transparent: true, opacity: 0.14 }),
    );
    knot.position.set(3.4, 0.6, -2);
    scene.add(knot);

    const resize = () => {
      renderer.setSize(innerWidth, innerHeight);
      camera.aspect = innerWidth / innerHeight;
      camera.updateProjectionMatrix();
    };
    resize();
    addEventListener('resize', resize);

    let raf = 0;
    const tick = (t) => {
      pts.rotation.y = t * 0.00004;
      knot.rotation.x = t * 0.0002;
      knot.rotation.y = t * 0.00013;
      camera.position.x += (mx * 0.9 - camera.position.x) * 0.04;
      camera.position.y += (-my * 0.6 - camera.position.y) * 0.04;
      camera.lookAt(0, 0, -2);
      renderer.render(scene, camera);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) cancelAnimationFrame(raf);
      else raf = requestAnimationFrame(tick);
    });
  }

  // ── canvas-2D starfield fallback ──────────────────────────────────────────
  function startFallback() {
    const ctx = canvas.getContext('2d');
    let W, H;
    const resize = () => { W = canvas.width = innerWidth; H = canvas.height = innerHeight; };
    resize();
    addEventListener('resize', resize);
    const stars = Array.from({ length: 180 }, () => ({
      x: Math.random(), y: Math.random(), z: 0.2 + Math.random() * 0.8, tw: Math.random() * Math.PI * 2,
    }));
    let raf = 0;
    const tick = (t) => {
      ctx.clearRect(0, 0, W, H);
      for (const s of stars) {
        const px = (s.x + mx * 0.012 * s.z) * W;
        const py = (s.y + my * 0.012 * s.z + t * 0.000004 * s.z) % 1 * H;
        const a = 0.25 + 0.55 * Math.abs(Math.sin(t * 0.001 + s.tw));
        ctx.fillStyle = (s.z > 0.6 ? accent2() : accent());
        ctx.globalAlpha = a * s.z;
        ctx.beginPath();
        ctx.arc(px, py, 1.1 + s.z * 1.4, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) cancelAnimationFrame(raf);
      else raf = requestAnimationFrame(tick);
    });
  }

  import('https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js')
    .then((THREE) => startThree(THREE))
    .catch(() => startFallback());
})();
