# Launchpad

An animated product landing page — three.js particle hero, scroll reveals,
count-up stats, tilting pricing cards — fully rebranded by editing one
content.json. This folder is a ForkScape App Template: open it in ForkScape,
hit **Run app**, and reshape it by talking to the canvas agents.
