# HabitFlow — project knowledge

A buildless glassmorphism habit tracker (static HTML/CSS/JS — no npm, no
bundler). Run app serves index.html directly.

## Where things live (edit here, not everywhere)
- **config.json** — title, tagline, accent + accent2 (the two gradient
  colors), daily quotes, seed habits. MOST wishes ("rename it", "make it
  emerald and gold", "different quotes") are a config.json edit. Valid JSON.
- **styles.css** — design tokens are the :root variables at the top (glass
  opacity, radius, backdrop hues, done-green). The aurora backdrop is the
  three .blob rules; animations are the named @keyframes. Restyle by tokens
  first, individual rules second.
- **app.js** — behavior: streaks, tabs (sliding pill), progress ring,
  confetti, localStorage persistence ('hf.habits'). New features go here.
- **index.html** — the shell incl. the SVG progress ring; rarely edited.

## Rules
- Keep it buildless: no npm packages, no framework rewrites.
- User data lives in localStorage — never rename 'hf.habits' without a
  migration in code.
- Respect prefers-reduced-motion (already wired — keep new animations
  inside it).
- After edits, refresh the preview; use the live-test agent (app_interact)
  to verify flows end to end.
