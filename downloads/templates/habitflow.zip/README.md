# HabitFlow

A glassmorphism habit tracker — aurora backdrop, frosted cards, animated
progress ring, confetti check-offs — that runs anywhere as a static page.
This folder is a ForkScape App Template: open it in ForkScape, hit
**Run app**, and edit it by talking to the canvas agents.
