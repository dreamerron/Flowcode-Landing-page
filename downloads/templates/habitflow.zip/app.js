// HabitFlow — buildless glassmorphism habit tracker. State in localStorage;
// branding & seed content in config.json (the file agents edit).
const $ = (s) => document.querySelector(s);
const todayKey = (d = new Date()) => d.toISOString().slice(0, 10);

let config = { title: 'HabitFlow', tagline: '', accent: '#8b7cf6', accent2: '#22d3ee', quotes: [], seedHabits: [], weekStartsMonday: true };
let habits = [];
let tab = 'today';

const load = () => { try { habits = JSON.parse(localStorage.getItem('hf.habits') ?? 'null') ?? []; } catch { habits = []; } };
const save = () => localStorage.setItem('hf.habits', JSON.stringify(habits));

function streak(h) {
  let n = 0;
  for (let d = 0; ; d++) {
    const day = new Date(Date.now() - d * 864e5);
    if (h.done[todayKey(day)]) n++;
    else if (d === 0) continue; // an unchecked today doesn't break yesterday's run
    else break;
  }
  return n;
}

function confetti(x, y) {
  const colors = [config.accent, config.accent2, '#4ade80', '#f472b6', '#facc15'];
  for (let i = 0; i < 14; i++) {
    const p = document.createElement('i');
    p.className = 'confetti';
    const a = Math.random() * Math.PI * 2, dist = 40 + Math.random() * 70;
    p.style.cssText = 'left:' + x + 'px;top:' + y + 'px;background:' + colors[i % colors.length] +
      ';--dx:' + Math.cos(a) * dist + 'px;--dy:' + (Math.sin(a) * dist - 30) + 'px;--rot:' + (Math.random() * 540 - 270) + 'deg;';
    document.body.appendChild(p);
    setTimeout(() => p.remove(), 850);
  }
}

function setRing() {
  const active = habits.filter((h) => !h.archived);
  const done = active.filter((h) => h.done[todayKey()]).length;
  const pct = active.length ? done / active.length : 0;
  const C = 2 * Math.PI * 34; // ring circumference (r=34)
  $('#ringfill').style.strokeDashoffset = String(C * (1 - pct));
  $('#ringpct').textContent = Math.round(pct * 100) + '%';
}

const TABS = ['today', 'habits', 'insights'];
function setPill() {
  $('#tabpill').style.transform = 'translateX(' + TABS.indexOf(tab) * 100 + '%)';
}

function render() {
  document.title = config.title;
  $('#title').textContent = config.title;
  document.documentElement.style.setProperty('--accent', config.accent);
  document.documentElement.style.setProperty('--accent2', config.accent2 ?? config.accent);
  const hour = new Date().getHours();
  $('#greet').textContent = hour < 5 ? 'Late night' : hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const q = config.quotes;
  $('#quote').textContent = q.length ? q[new Date().getDate() % q.length] : config.tagline;
  document.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  setPill();
  setRing();
  const view = $('#view');
  const active = habits.filter((h) => !h.archived);

  if (tab === 'today') {
    view.innerHTML = '<h2>' + new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' }) + '</h2>';
    if (!active.length) view.innerHTML += '<p class="empty">No habits yet — add your first on the Habits tab.</p>';
    active.forEach((h, i) => {
      const done = !!h.done[todayKey()];
      const el = document.createElement('button');
      el.className = 'habit' + (done ? ' done' : '');
      el.style.setProperty('--i', String(i));
      el.innerHTML = '<span class="icon">' + h.icon + '</span><span class="name">' + h.name + '</span>' +
        '<span class="streak">🔥 ' + streak(h) + '</span><span class="ringk">✓</span>';
      el.onclick = (ev) => {
        h.done[todayKey()] = !done;
        save();
        if (!done) confetti(ev.clientX || innerWidth / 2, ev.clientY || 300);
        render();
        if (!done) {
          const fresh = [...view.querySelectorAll('.habit')][i];
          fresh?.classList.add('pop');
        }
      };
      view.appendChild(el);
    });
  } else if (tab === 'habits') {
    view.innerHTML = '<h2>Your habits</h2>';
    active.forEach((h, i) => {
      const row = document.createElement('div');
      row.className = 'habit';
      row.style.setProperty('--i', String(i));
      row.innerHTML = '<span class="icon">' + h.icon + '</span><span class="name">' + h.name + '</span>';
      const btn = document.createElement('button');
      btn.className = 'archive';
      btn.textContent = 'archive';
      btn.onclick = () => { h.archived = true; save(); render(); };
      row.appendChild(btn);
      view.appendChild(row);
    });
    const addRow = document.createElement('div');
    addRow.className = 'addrow';
    addRow.innerHTML = '<input id="new-habit" placeholder="New habit…" aria-label="New habit"><button id="add">Add</button>';
    view.appendChild(addRow);
    const commit = () => {
      const name = $('#new-habit').value.trim();
      if (!name) return;
      habits.push({ name, icon: '🌱', done: {}, archived: false });
      save(); render();
    };
    $('#add').onclick = commit;
    $('#new-habit').onkeydown = (e) => e.key === 'Enter' && commit();
  } else {
    view.innerHTML = '<h2>Last 7 days</h2>';
    const bars = document.createElement('div');
    bars.className = 'bars';
    const max = Math.max(1, active.length);
    let bi = 0;
    for (let d = 6; d >= 0; d--) {
      const day = new Date(Date.now() - d * 864e5);
      const count = active.filter((h) => h.done[todayKey(day)]).length;
      const bar = document.createElement('div');
      bar.className = 'bar';
      bar.innerHTML = '<div class="fill" style="height:' + Math.max(5, Math.round((count / max) * 100)) + '%;--i:' + bi++ + '"></div>' +
        '<span class="lbl">' + day.toLocaleDateString(undefined, { weekday: 'narrow' }) + '</span>';
      bars.appendChild(bar);
    }
    view.appendChild(bars);
    const best = active.length ? Math.max(0, ...active.map(streak)) : 0;
    const doneToday = active.filter((h) => h.done[todayKey()]).length;
    view.innerHTML += '<div class="stat" style="--i:1"><span>Best streak</span><b>🔥 ' + best + '</b></div>' +
      '<div class="stat" style="--i:2"><span>Completed today</span><b>' + doneToday + ' / ' + active.length + '</b></div>';
  }
}

document.querySelectorAll('.tabs button').forEach((b) => (b.onclick = () => { tab = b.dataset.tab; render(); }));

fetch('config.json').then((r) => r.json()).then((c) => {
  config = { ...config, ...c };
  load();
  if (!habits.length && !localStorage.getItem('hf.seeded')) {
    habits = config.seedHabits.map((h) => ({ ...h, done: {}, archived: false }));
    localStorage.setItem('hf.seeded', '1');
    save();
  }
  render();
}).catch(() => { load(); render(); });
