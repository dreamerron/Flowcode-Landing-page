# Shopfront

An online-ordering storefront for a restaurant or product shop: browsable
menu with categories, cart with a free-delivery progress bar, delivery or
pickup checkout, and order history — the whole catalog and brand live in
config.json. This folder is a ForkScape App Template: open it in ForkScape,
hit **Run app**, and reshape it by talking to the canvas agents.
