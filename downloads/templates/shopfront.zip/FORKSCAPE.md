# Shopfront — project knowledge

A restaurant/product online-ordering storefront: category-filtered catalog,
cart with delivery-fee rules, checkout (delivery or pickup), order history.
Buildless — static HTML/CSS/JS, no npm.

## Files
- **config.json** — THE product surface: storeName, tagline, currency,
  accent/accent2 (drive every gradient), orderPhone (WhatsApp handoff on the
  confirmation, digits only with country code, empty = hide the button),
  deliveryFee + freeDeliveryOver (0 disables the progress bar), categories,
  and the full products array ({ name, cat, price, emoji, desc, tag? }).
  EDIT THIS FIRST — turning the demo restaurant into a bakery, grocery,
  boutique, or electronics shop is purely a config.json rewrite.
- **app.js** — all logic: cart is { productName: qty } (in-memory), placed
  orders persist in localStorage 'sf.orders'. delFee() waives delivery for
  pickup and at/above freeDeliveryOver. One render() over Menu/Cart/Orders +
  checkout/confirmation; one delegated click handler. New features go here.
- **styles.css** — sleek Apple-style DARK theme (iOS dark-mode palette):
  near-black --bg ground, elevated graphite --card surfaces, neutral --fill
  controls, pill buttons, frosted dark segmented tab bar with a graphite
  sliding thumb. Accents arrive at runtime from config.json. Keep the
  reduced-motion guard at the bottom.
- **index.html** — the static shell (#cats chips, #view, fixed .tabs pill).

## Rules for agents
- Keep it buildless — no npm, no frameworks, no CDN dependencies.
- Product names are the cart keys — keep them unique in config.json.
- Order history lives in localStorage 'sf.orders' — never rename the key or
  break the shape without a migration in load().
- Currency formatting goes through fmt() — never hardcode a symbol.
- Emoji stand in for product photos so the template stays self-contained;
  if the user supplies real images, add an optional img field that falls
  back to emoji.
