// Shopfront — buildless ordering storefront. The catalog is 100%
// config.json; the cart is { [productName]: qty }; placed orders persist in
// localStorage 'sf.orders'. Totals: delivery fee applies below
// freeDeliveryOver (waived at/above it, and for pickup). One render() over
// three tabs + a checkout/confirmation flow; one delegated click handler.
let cfg = { storeName: 'Shopfront', tagline: '', currency: '₹', accent: '#0a84ff', accent2: '#64d2ff', orderPhone: '', deliveryFee: 0, freeDeliveryOver: 0, categories: [], products: [] };
let cart = {};      // product name → qty
let orders = [];
let tab = 'menu';
let cat = 'All';
let mode = 'delivery';
let checkingOut = false;
let placed = null;  // last confirmation, shown once

const $ = (s) => document.querySelector(s);
const load = () => { try { orders = JSON.parse(localStorage.getItem('sf.orders') ?? '[]'); } catch { orders = []; } };
const save = () => localStorage.setItem('sf.orders', JSON.stringify(orders));
const fmt = (n) => cfg.currency + Math.round(n).toLocaleString('en-IN');
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const prodBy = (name) => cfg.products.find((p) => p.name === name);
const cartCount = () => Object.values(cart).reduce((a, b) => a + b, 0);
const subtotal = () => Object.entries(cart).reduce((s, [n, q]) => s + (prodBy(n)?.price ?? 0) * q, 0);
const delFee = () => (mode === 'pickup' || subtotal() >= cfg.freeDeliveryOver || subtotal() === 0) ? 0 : cfg.deliveryFee;

function stepper(name, qty) {
  return '<span class="step"><button data-dec="' + esc(name) + '" aria-label="Less">−</button><b>' + qty + '</b><button data-inc="' + esc(name) + '" aria-label="More">+</button></span>';
}

function renderMenu() {
  const list = cfg.products.filter((p) => cat === 'All' || p.cat === cat);
  $('#view').innerHTML = '<div class="grid2">' + list.map((p, i) =>
    '<div class="prod" style="--i:' + i + '">' +
    (p.tag ? '<span class="tag">' + esc(p.tag) + '</span>' : '') +
    '<span class="art">' + p.emoji + '</span><b>' + esc(p.name) + '</b>' +
    '<span class="desc">' + esc(p.desc ?? '') + '</span>' +
    '<span class="rowb"><span class="price">' + fmt(p.price) + '</span>' +
    (cart[p.name] ? stepper(p.name, cart[p.name]) : '<button class="addbtn" data-add="' + esc(p.name) + '">Add</button>') +
    '</span></div>').join('') + '</div>';
}

function renderCart() {
  if (placed) { renderConfirm(); return; }
  if (!cartCount()) {
    $('#view').innerHTML = '<div class="card empty" style="--i:0">Your cart is empty — add something tasty from the menu.</div>';
    return;
  }
  const lines = Object.entries(cart).map(([n, q], i) => {
    const p = prodBy(n);
    return '<div class="line" style="--i:' + i + '"><span class="art">' + p.emoji + '</span>' +
      '<span class="who"><b>' + esc(n) + '</b><span>' + fmt(p.price) + ' × ' + q + ' = ' + fmt(p.price * q) + '</span></span>' +
      stepper(n, q) + '</div>';
  }).join('');
  const sub = subtotal(), fee = delFee();
  const toFree = Math.max(0, cfg.freeDeliveryOver - sub);
  const freebar = (mode === 'delivery' && cfg.freeDeliveryOver > 0)
    ? '<div class="card freebar" style="--i:' + Object.keys(cart).length + '">' +
      (toFree > 0 ? '<p>Add <b>' + fmt(toFree) + '</b> more for free delivery</p>' : '<p><b>You unlocked free delivery 🎉</b></p>') +
      '<span class="track"><i style="width:' + Math.min(100, (sub / cfg.freeDeliveryOver) * 100) + '%"></i></span></div>'
    : '';
  const form = checkingOut
    ? '<div class="card form" style="--i:9">' +
      '<div class="modes"><button id="m-del" class="' + (mode === 'delivery' ? 'on' : '') + '">🛵 Delivery</button>' +
      '<button id="m-pick" class="' + (mode === 'pickup' ? 'on' : '') + '">🏃 Pickup</button></div>' +
      '<input id="c-name" placeholder="Your name">' +
      '<input id="c-phone" type="tel" inputmode="tel" placeholder="Phone number">' +
      (mode === 'delivery' ? '<textarea id="c-addr" rows="2" placeholder="Delivery address"></textarea>' : '') +
      '<button id="place" class="cta">Place order · ' + fmt(sub + fee) + '</button></div>'
    : '<button id="checkout" class="cta" style="--i:9">Checkout · ' + fmt(sub + fee) + '</button>';
  $('#view').innerHTML = lines + freebar +
    '<div class="card" style="--i:8;padding:10px 0 14px">' +
    '<div class="sumline"><span>Subtotal</span><b id="sub">' + fmt(sub) + '</b></div>' +
    '<div class="sumline"><span>Delivery</span>' + (fee === 0 ? '<b class="free">FREE</b>' : '<b>' + fmt(fee) + '</b>') + '</div>' +
    '<div class="sumline total"><span>Total</span><b id="total">' + fmt(sub + fee) + '</b></div></div>' + form;
}

function renderConfirm() {
  const o = placed;
  $('#view').innerHTML =
    '<div class="card confirm" style="--i:0"><div class="tick">✓</div>' +
    '<h2>Order placed!</h2><p class="oid">#' + o.id + '</p>' +
    '<p>' + o.items + ' item' + (o.items > 1 ? 's' : '') + ' · ' + fmt(o.total) + ' · ' + (o.mode === 'pickup' ? 'pickup' : 'delivery') + '<br>' +
    "We'll " + (o.mode === 'pickup' ? 'have it ready for you' : 'be at your door') + ' shortly, ' + esc(o.name) + '.</p>' +
    (cfg.orderPhone ? '<a class="cta" style="display:block;text-decoration:none" target="_blank" rel="noopener" href="https://wa.me/' + cfg.orderPhone + '?text=' + encodeURIComponent('Order #' + o.id + ' — ' + o.summary) + '">Send on WhatsApp</a>' : '') +
    '</div>';
}

function renderOrders() {
  $('#view').innerHTML = orders.length
    ? [...orders].reverse().map((o, i) =>
        '<div class="order" style="--i:' + i + '"><div class="top"><span>#' + o.id + '</span><span class="st">' + esc(o.status) + '</span></div>' +
        '<div class="sub">' + esc(o.summary) + '</div>' +
        '<div class="sub">' + o.items + ' item' + (o.items > 1 ? 's' : '') + ' · <b style="color:var(--ink)">' + fmt(o.total) + '</b> · ' + (o.mode === 'pickup' ? '🏃 pickup' : '🛵 delivery') + '</div></div>').join('')
    : '<div class="card empty" style="--i:0">No orders yet — your history shows up here.</div>';
}

function render() {
  $('#storename').textContent = cfg.storeName;
  $('#tagline').textContent = cfg.tagline;
  const idx = ['menu', 'cart', 'orders'].indexOf(tab);
  $('#tabpill').style.transform = 'translateX(' + idx * 100 + '%)';
  document.querySelectorAll('.tabs > button').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  const n = cartCount();
  const badge = $('#cart-badge');
  badge.hidden = n === 0;
  badge.textContent = n;
  $('#cats').innerHTML = ['All', ...cfg.categories].map((c) =>
    '<button data-cat="' + esc(c) + '" class="' + (c === cat ? 'on' : '') + '">' + esc(c) + '</button>').join('');
  $('#cats').style.display = tab === 'menu' ? '' : 'none';
  if (tab === 'menu') renderMenu();
  else if (tab === 'cart') renderCart();
  else renderOrders();
}

document.addEventListener('click', (e) => {
  const el = e.target.closest('button, a.cta');
  if (!el) return;
  if (el.dataset.tab) { tab = el.dataset.tab; if (tab !== 'cart') placed = null; render(); return; }
  if (el.dataset.cat) { cat = el.dataset.cat; render(); return; }
  if (el.dataset.add) { cart[el.dataset.add] = 1; render(); return; }
  if (el.dataset.inc) { cart[el.dataset.inc]++; render(); return; }
  if (el.dataset.dec) {
    const n = el.dataset.dec;
    if (--cart[n] <= 0) delete cart[n];
    if (!cartCount()) checkingOut = false;
    render();
    return;
  }
  if (el.id === 'checkout') { checkingOut = true; render(); return; }
  if (el.id === 'm-del' || el.id === 'm-pick') {
    // Preserve typed contact fields across the re-render.
    const keep = { name: $('#c-name')?.value ?? '', phone: $('#c-phone')?.value ?? '' };
    mode = el.id === 'm-del' ? 'delivery' : 'pickup';
    render();
    if ($('#c-name')) $('#c-name').value = keep.name;
    if ($('#c-phone')) $('#c-phone').value = keep.phone;
    return;
  }
  if (el.id === 'place') {
    const name = $('#c-name').value.trim(), phone = $('#c-phone').value.trim();
    const addr = $('#c-addr')?.value.trim() ?? '';
    if (!name || !phone || (mode === 'delivery' && !addr)) {
      for (const id of ['c-name', 'c-phone', 'c-addr']) {
        const f = $('#' + id);
        if (f && !f.value.trim()) f.style.borderColor = 'var(--accent)';
      }
      return;
    }
    const summary = Object.entries(cart).map(([n, q]) => n + ' ×' + q).join(', ');
    const o = {
      id: Math.random().toString(36).slice(2, 7).toUpperCase(),
      ts: Date.now(), name, phone, addr, mode, summary,
      items: cartCount(), total: subtotal() + delFee(), status: 'Placed',
    };
    orders.push(o);
    save();
    cart = {};
    checkingOut = false;
    placed = o;
    render();
  }
});

fetch('config.json').then((r) => r.json()).then((c) => {
  cfg = { ...cfg, ...c };
  document.documentElement.style.setProperty('--accent', cfg.accent);
  document.documentElement.style.setProperty('--accent2', cfg.accent2 ?? cfg.accent);
  document.title = cfg.storeName;
  load();
  render();
});
