// KhataPad — buildless small-business khata. Parties hold a transaction
// ledger ('gave' = credit you extended, 'got' = payment received; balance =
// gave − got, positive means you'll GET). Items hold live stock. Everything
// persists in localStorage ('kp.data'); config.json seeds the first run and
// carries branding. Rendering is one render() over three tab views with
// event delegation — no frameworks, no build.
let cfg = { shopName: 'KhataPad', tagline: '', currency: '₹', accent: '#cc785c', accent2: '#d9a27b', lowStockAlert: 10, seedParties: [], seedItems: [] };
let data = { parties: [], items: [] };
let tab = 'parties';
let openParty = null; // party id when the ledger detail is open

const $ = (s) => document.querySelector(s);
const load = () => { try { data = JSON.parse(localStorage.getItem('kp.data') ?? 'null') ?? data; } catch { /* keep defaults */ } };
const save = () => localStorage.setItem('kp.data', JSON.stringify(data));
const uid = () => Math.random().toString(36).slice(2, 9);
const fmt = (n) => cfg.currency + Math.abs(Math.round(n)).toLocaleString('en-IN');
const balOf = (p) => p.txns.reduce((s, t) => s + (t.type === 'gave' ? t.amt : -t.amt), 0);
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function totals() {
  let get = 0, give = 0;
  for (const p of data.parties) { const b = balOf(p); if (b > 0) get += b; else give -= b; }
  const stock = data.items.reduce((s, i) => s + i.qty * i.price, 0);
  return { get, give, stock };
}

function renderHeader() {
  const t = totals();
  $('#shopname').textContent = cfg.shopName;
  $('#tagline').textContent = cfg.tagline;
  $('#tot-get').textContent = fmt(t.get);
  $('#tot-give').textContent = fmt(t.give);
}

function chip(b) {
  if (b > 0) return '<span class="chip get">' + fmt(b) + ' ›</span>';
  if (b < 0) return '<span class="chip give">' + fmt(b) + ' ‹</span>';
  return '<span class="chip zero">settled</span>';
}

function renderParties() {
  const rows = data.parties.map((p, i) => {
    const b = balOf(p);
    const last = p.txns[p.txns.length - 1];
    return '<div class="party" data-party="' + p.id + '" style="--i:' + i + '">' +
      '<span class="avatar">' + esc(p.name[0].toUpperCase()) + '</span>' +
      '<span class="who"><b>' + esc(p.name) + '</b><span>' + (last ? (last.type === 'gave' ? 'You gave ' : 'You got ') + fmt(last.amt) : esc(p.phone ?? '')) + '</span></span>' +
      chip(b) + '</div>';
  }).join('');
  $('#view').innerHTML =
    (rows || '<div class="card empty">No parties yet — add your first customer below.</div>') +
    '<div class="addrow" style="--i:' + data.parties.length + '">' +
    '<input id="new-party" placeholder="Party name (customer or supplier)">' +
    '<button id="add-party">Add</button></div>';
}

function renderLedger(p) {
  const b = balOf(p);
  const rows = [...p.txns].reverse().map((t, i) =>
    '<div class="txn" style="--i:' + (i + 2) + '">' +
    '<span><b class="' + t.type + '">' + (t.type === 'gave' ? 'You gave' : 'You got') + '</b>' +
    '<span class="note"> · ' + esc(t.note || (t.type === 'gave' ? 'credit' : 'payment')) + '</span></span>' +
    '<b class="' + t.type + '">' + fmt(t.amt) + '</b></div>').join('');
  $('#view').innerHTML =
    '<div class="backbar"><button id="back">‹ Parties</button><h2 style="margin:0;font-size:18px">' + esc(p.name) + '</h2></div>' +
    '<div class="card balhead ' + (b >= 0 ? 'get' : 'give') + '" style="--i:0"><span>' + (b > 0 ? "You'll get" : b < 0 ? "You'll give" : 'Settled up') + '</span><b id="bal">' + fmt(b) + '</b></div>' +
    '<div class="entry" style="--i:1">' +
    '<input id="amt" type="number" min="1" inputmode="numeric" placeholder="Amount">' +
    '<button id="btn-gave">You gave ›</button><button id="btn-got">‹ You got</button></div>' +
    (rows || '<div class="card empty">No entries yet — record the first one above.</div>');
}

function renderStock() {
  const rows = data.items.map((it, i) =>
    '<div class="item" data-item="' + it.id + '" style="--i:' + i + '">' +
    '<span class="who"><b>' + esc(it.name) + (it.qty <= cfg.lowStockAlert ? '<span class="low">LOW</span>' : '') + '</b>' +
    '<span>' + fmt(it.price) + ' / ' + esc(it.unit) + ' · worth ' + fmt(it.qty * it.price) + '</span></span>' +
    '<span class="qty"><button data-out="' + it.id + '" aria-label="Stock out">−</button><b>' + it.qty + ' ' + esc(it.unit) + '</b><button data-in="' + it.id + '" aria-label="Stock in">+</button></span></div>').join('');
  $('#view').innerHTML =
    (rows || '<div class="card empty">No items yet — add your first product below.</div>') +
    '<div class="addrow" style="--i:' + data.items.length + '">' +
    '<input id="new-item" placeholder="Item name">' +
    '<input id="new-qty" class="num" type="number" min="0" placeholder="Qty">' +
    '<input id="new-price" class="num" type="number" min="0" placeholder="Price">' +
    '<button id="add-item">Add</button></div>';
}

function renderReports() {
  const t = totals();
  const debtors = data.parties.map((p) => ({ p, b: balOf(p) })).filter((x) => x.b > 0).sort((a, b) => b.b - a.b);
  const low = data.items.filter((i) => i.qty <= cfg.lowStockAlert);
  $('#view').innerHTML =
    '<div class="stats">' +
    '<div class="stat get" style="--i:0"><span>To collect</span><b data-target="' + t.get + '">' + fmt(0) + '</b></div>' +
    '<div class="stat give" style="--i:1"><span>To pay</span><b data-target="' + t.give + '">' + fmt(0) + '</b></div>' +
    '<div class="stat" style="--i:2"><span>Stock value</span><b data-target="' + t.stock + '">' + fmt(0) + '</b></div>' +
    '<div class="stat" style="--i:3"><span>Parties</span><b>' + data.parties.length + '</b></div></div>' +
    '<p class="section-title">Top to collect</p>' +
    (debtors.slice(0, 5).map((x, i) => '<div class="card rowline" style="--i:' + (i + 4) + '"><span>' + esc(x.p.name) + '</span><b style="color:var(--get)">' + fmt(x.b) + '</b></div>').join('') || '<div class="card empty">Nothing to collect — all settled.</div>') +
    '<p class="section-title">Low stock</p>' +
    (low.map((it, i) => '<div class="card rowline" style="--i:' + (i + 9) + '"><span>' + esc(it.name) + '</span><b style="color:var(--low, var(--accent2))">' + it.qty + ' ' + esc(it.unit) + ' left</b></div>').join('') || '<div class="card empty">Stock levels are healthy.</div>');
  countUp();
}

// Count-up on the report numbers (respects reduced motion by skipping).
function countUp() {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.querySelectorAll('[data-target]').forEach((b) => { b.textContent = fmt(+b.dataset.target); });
    return;
  }
  document.querySelectorAll('[data-target]').forEach((b) => {
    const target = +b.dataset.target, t0 = performance.now(), dur = 900;
    const step = (now) => {
      const p = Math.min(1, (now - t0) / dur);
      b.textContent = fmt(target * (1 - Math.pow(1 - p, 3)));
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  });
}

function render() {
  renderHeader();
  const idx = ['parties', 'stock', 'reports'].indexOf(tab);
  $('#tabpill').style.transform = 'translateX(' + idx * 100 + '%)';
  document.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  const p = openParty && data.parties.find((x) => x.id === openParty);
  if (tab === 'parties' && p) renderLedger(p);
  else if (tab === 'parties') renderParties();
  else if (tab === 'stock') renderStock();
  else renderReports();
}

// One delegated click handler runs the whole app.
document.addEventListener('click', (e) => {
  const el = e.target.closest('button, .party');
  if (!el) return;
  if (el.dataset.tab) { tab = el.dataset.tab; openParty = null; render(); return; }
  if (el.classList.contains('party')) { openParty = el.dataset.party; render(); return; }
  if (el.id === 'back') { openParty = null; render(); return; }
  if (el.id === 'btn-gave' || el.id === 'btn-got') {
    const amt = +$('#amt').value;
    const p = data.parties.find((x) => x.id === openParty);
    if (!p || !(amt > 0)) return;
    p.txns.push({ type: el.id === 'btn-gave' ? 'gave' : 'got', amt, note: '', ts: Date.now() });
    save(); render();
    return;
  }
  if (el.id === 'add-party') {
    const name = $('#new-party').value.trim();
    if (!name) return;
    data.parties.unshift({ id: uid(), name, phone: '', txns: [] });
    save(); render();
    return;
  }
  if (el.id === 'add-item') {
    const name = $('#new-item').value.trim();
    if (!name) return;
    data.items.push({ id: uid(), name, unit: 'pc', qty: Math.max(0, +$('#new-qty').value || 0), price: Math.max(0, +$('#new-price').value || 0) });
    save(); render();
    return;
  }
  if (el.dataset.in || el.dataset.out) {
    const it = data.items.find((x) => x.id === (el.dataset.in || el.dataset.out));
    if (!it) return;
    it.qty = Math.max(0, it.qty + (el.dataset.in ? 1 : -1));
    save(); render();
  }
});

fetch('config.json').then((r) => r.json()).then((c) => {
  cfg = { ...cfg, ...c };
  document.documentElement.style.setProperty('--accent', cfg.accent);
  document.documentElement.style.setProperty('--accent2', cfg.accent2 ?? cfg.accent);
  document.title = cfg.shopName;
  load();
  if (!data.parties.length && !data.items.length && !localStorage.getItem('kp.seeded')) {
    data.parties = (cfg.seedParties ?? []).map((p) => ({ id: uid(), name: p.name, phone: p.phone ?? '', txns: (p.txns ?? []).map((t) => ({ ...t, ts: Date.now() })) }));
    data.items = (cfg.seedItems ?? []).map((i) => ({ id: uid(), ...i }));
    localStorage.setItem('kp.seeded', '1');
    save();
  }
  render();
});
