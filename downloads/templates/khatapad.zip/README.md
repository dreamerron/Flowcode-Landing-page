# KhataPad

A small-business khata: track what customers owe you and what you owe
suppliers, keep a live stock book with low-stock alerts, and read the
day's position off the Reports tab. Fully rebrandable through config.json.
This folder is a ForkScape App Template: open it in ForkScape, hit
**Run app**, and reshape it by talking to the canvas agents.
