# KhataPad — project knowledge

A KhataBook-style small-business app: customer/supplier khata (credit ledger)
plus a stock book and reports. Buildless — static HTML/CSS/JS, no npm.

## Files
- **config.json** — branding + behavior: shopName, tagline, currency symbol,
  accent/accent2 (drive every gradient), lowStockAlert threshold, and the
  first-run seed parties/items. EDIT THIS FIRST for any rebrand or locale
  change (e.g. currency "$", different seed data).
- **app.js** — all logic: state shape { parties: [{ id, name, phone, txns:
  [{ type: 'gave'|'got', amt, note, ts }] }], items: [{ id, name, unit, qty,
  price }] }. balance = gave − got (positive ⇒ you'll GET). Rendering is one
  render() over three tabs + a party ledger detail; one delegated click
  handler. New features go here.
- **styles.css** — Claude-style theme: warm paper tokens in :root (--paper,
  --card, --brd, --shadow), terracotta accents from config.json at runtime,
  serif (Georgia) display headings and money figures. Keep the
  reduced-motion guard at the bottom.
- **index.html** — the static shell (#view + fixed .tabs pill nav).

## Rules for agents
- Keep it buildless — no npm, no frameworks, no CDN dependencies.
- User data lives in localStorage 'kp.data' — never rename the key or break
  the shape without writing a migration in the load() path.
- 'gave' means credit extended (they owe you, red row, green balance chip);
  'got' means payment received. Keep that sign convention everywhere.
- Currency formatting goes through fmt() — never hardcode a symbol.
